
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let player = { x: 100, y: canvas.height - 150, width: 50, height: 50, vy: 0, jumpPower: -15, gravity: 0.8, grounded: true };

function drawPlayer() {
    ctx.fillStyle = "blue";
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    player.vy += player.gravity;
    player.y += player.vy;

    if (player.y + player.height >= canvas.height) {
        player.y = canvas.height - player.height;
        player.vy = 0;
        player.grounded = true;
    }

    drawPlayer();
    requestAnimationFrame(update);
}

window.addEventListener("keydown", (e) => {
    if (e.code === "Space" && player.grounded) {
        player.vy = player.jumpPower;
        player.grounded = false;
    }
});

update();
